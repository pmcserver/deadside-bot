import { env } from "@/env";
import { ColorResolvable, EmbedBuilder } from "discord.js";

export class BotEmbed extends EmbedBuilder {
  constructor() {
    super();

    this.setColor(env.BOT_COLOR as ColorResolvable);
  }
}
