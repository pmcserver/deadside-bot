import { Bot } from "@/bot";
import { ApplicationCommandData, CommandInteraction } from "discord.js";

export abstract class Command {
  constructor(public readonly client: Bot, public readonly data: ApplicationCommandData) {}

  abstract run(interaction: CommandInteraction): Promise<void>;

  get name() {
    return this.data.name;
  }
}
