import { Bot } from "@/bot";
import type { ClientEvents } from "discord.js";

export abstract class Event {
  constructor(public readonly client: Bot, public readonly eventName: keyof ClientEvents) {}

  abstract execute(...args: unknown[]): Promise<void>;
}
