import { z } from "zod";

export const env = z.object({
  DISCORD_TOKEN: z.string(),
  DISCORD_GUILD_ID: z.string().regex(/^\d+$/gi),
  BOT_COLOR: z.string()
}).parse(process.env);
