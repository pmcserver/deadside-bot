import { Bot } from "@/bot";
import { prisma } from "@/libs/prisma";
import { Command } from "@/structures/command";
import { BotEmbed } from "@/structures/embed";
import { getItemByItemId } from "@/utils/roll";
import { InventoryItem } from "@prisma/client";
import { ApplicationCommandOptionType, ChatInputCommandInteraction } from "discord.js";

export default class extends Command {
  constructor(client: Bot) {
    super(client, {
      name: 'inventario',
      description: 'Obtem o inventário do usuário',
      options: [
        {
          name: 'usuário',
          description: 'Obtem o inventário do usuário fornecido',
          type: ApplicationCommandOptionType.User,
          required: false,
        }
      ]
    })
  }

  async run(interaction: ChatInputCommandInteraction<'cached'>) {
    const user = interaction.options.get('usuário');
    const target = user ? user.member : interaction.member;

    if (!target || target.user.bot) {
      await interaction.reply({
        content: 'Usuário inválido.',
        ephemeral: true,
      })
      return;
    }

    if (target.id !== interaction.user.id) {
      if (!interaction.memberPermissions.has('Administrator')) {
        await interaction.reply({
          content: 'Você não tem permissão para visualizar o inventário de outro usuário.',
          ephemeral: true,
        })
        return;
      }
    }

    const inventory = await prisma.user.findUnique({
      where: {
        id: target.user.id,
      },
      select: {
        inventoryItems: true,
      }
    });

    const inventoryItems = (inventory?.inventoryItems ?? []).reduce<InventoryItem[]>((acc, val) => {
      const idx = acc.findIndex(x => x.itemId === val.itemId);
      if (idx > -1) {
        acc[idx].amount += val.amount;
      } else {
        acc.push(val);
      }

      return acc;
    }, []);

    const embed = new BotEmbed()
      .setTitle(`Inventário de ${target.user.username}`)
      .setDescription(
        inventoryItems.length
          ? inventoryItems.map(x => {
            const item = getItemByItemId(x.itemId);
            return `\`${x.amount}x\` ${item?.name}`
          }).join('\n')
          :'Nenhum item'
      );

    await interaction.reply({
      embeds: [embed],
    })
  }
}
