import { Bot } from "@/bot";
import { Command } from "@/structures/command";
import { ChatInputCommandInteraction } from "discord.js";

export default class extends Command {
  constructor(client: Bot) {
    super(client, {
      name: 'ping',
      description: 'Obtem a latência do bot.'
    });
  }

  async run(interaction: ChatInputCommandInteraction) {
    const ms = interaction.client.ws.ping;
    await interaction.reply({
      content: `Latência: \`${ms}ms\``,
      ephemeral: true,
    })
  }
}
