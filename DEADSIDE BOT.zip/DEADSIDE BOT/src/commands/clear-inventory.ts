import { Bot } from "@/bot";
import { prisma } from "@/libs/prisma";
import { Command } from "@/structures/command";
import { ApplicationCommandOptionType, ChatInputCommandInteraction } from "discord.js";

export default class extends Command {
  constructor(client: Bot) {
    super(client, {
      name: 'limpar-inventário',
      description: 'Limpa o inventário de um usuário',
      defaultMemberPermissions: ['Administrator'],
      options: [
        {
          name: 'usuário',
          description: 'Usuário que terá o inventário limpo',
          type: ApplicationCommandOptionType.User,
          required: true,
        }
      ]
    })
  }

  async run(interaction: ChatInputCommandInteraction<'cached'>) {
    const target = interaction.options.getMember('usuário');

    if (!target || target.user.bot) {
      await interaction.reply({
        content: 'Usuário inválido.'
      });
      return;
    }

    await interaction.deferReply();

    await prisma.user.update({
      where: {
        id: target.id,
      },
      data: {
        inventoryItems: {
          deleteMany: {}
        }
      }
    });

    await interaction.editReply({
      content: `Você resetou o inventário de ${target}!`,
    })
  }
}
