import { Bot } from "@/bot";
import { prisma } from "@/libs/prisma";
import { Command } from "@/structures/command";
import { Duration, getMSFromNow } from "@/utils/date";
import { getRandomItemByChance } from "@/utils/roll";
import generalConfig from '@/config/general.json' assert { type: "json" };
import { ApplicationCommandOptionType, ChatInputCommandInteraction } from "discord.js";

export default class extends Command {
  constructor(client: Bot) {
    super(client, {
      name: 'sorte',
      description: 'Utilize da sua sorte para ganhar itens!',
      options: [
        {
          name: 'diaria',
          description: 'Tente a sorte diaria!',
          type: ApplicationCommandOptionType.Subcommand,
        },
        {
          name: 'semanal',
          description: 'Tente a sorte semanal!',
          type: ApplicationCommandOptionType.Subcommand,
        },
        {
          name: 'mensal',
          description: 'Tente a sorte mensal!',
          type: ApplicationCommandOptionType.Subcommand
        }
      ]
    })
  }

  async run(interaction: ChatInputCommandInteraction<'cached'>) {
    await interaction.deferReply();

    const userData = await prisma.user.findUnique({
      where: {
        id: interaction.user.id,
      },
      select: {
        lastDailyRollAt: true,
        lastMonthlyRollAt: true,
        lastWeeklyRollAt: true,
      }
    });

    const subcommand = interaction.options.getSubcommand();
    const logsChannel = interaction.guild.channels.resolve(generalConfig.logs_channel);

    if (subcommand === 'diaria') {
      if (userData?.lastDailyRollAt && getMSFromNow(userData.lastDailyRollAt) < Duration.Day) {
        await interaction.editReply({
          content: `Você poderá fazer seu resgate diário novamente <t:${~~((Date.now() + Duration.Day - getMSFromNow(userData.lastDailyRollAt)) / 1000)}:R>.`
        })
        return;
      }

      const item = getRandomItemByChance('daily');

      await prisma.user.upsert({
        where: {
          id: interaction.user.id,
        },
        create: {
          id: interaction.user.id,
          inventoryItems: {
            create: {
              amount: 1,
              itemId: item.id,
            }
          },
          lastDailyRollAt: new Date(),
        },
        update: {
          inventoryItems: {
            create: {
              amount: 1,
              itemId: item.id,
            }
          },
          lastDailyRollAt: new Date(),
        }
      });

      await interaction.editReply({
        embeds: [
          {
            color: 0x00ff00,
            description: `Você ganhou 1x **${item.name}** na sua sorte diária!`
          }
        ]
      })

      if (logsChannel?.isTextBased()) {
        await logsChannel.send({
          embeds: [
            {
              color: 0x0084ff,
              author: {
                name: interaction.user.username,
                icon_url: interaction.user.displayAvatarURL(),
              },
              description: `Tirou 1x **${item.name}** na sorte diária!`
            }
          ]
        })
      }
    }

    if (subcommand === 'semanal') {
      if (userData?.lastWeeklyRollAt && getMSFromNow(userData.lastWeeklyRollAt) < Duration.Week) {
        await interaction.editReply({
          content: `Você poderá fazer seu resgate semanal novamente <t:${~~((Date.now() + Duration.Week - getMSFromNow(userData.lastWeeklyRollAt)) / 1000)}:R>.`
        })
        return;
      }

      const item = getRandomItemByChance('weekly');

      await prisma.user.upsert({
        where: {
          id: interaction.user.id,
        },
        create: {
          id: interaction.user.id,
          inventoryItems: {
            create: {
              amount: 1,
              itemId: item.id,
            }
          },
          lastWeeklyRollAt: new Date(),
        },
        update: {
          inventoryItems: {
            create: {
              amount: 1,
              itemId: item.id,
            }
          },
          lastWeeklyRollAt: new Date(),
        }
      });

      await interaction.editReply({
        embeds: [
          {
            color: 0x00ff00,
            description: `Você ganhou 1x **${item.name}** na sua sorte semanal!`
          }
        ]
      })

      if (logsChannel?.isTextBased()) {
        await logsChannel.send({
          embeds: [
            {
              color: 0xffff00,
              author: {
                name: interaction.user.username,
                icon_url: interaction.user.displayAvatarURL(),
              },
              description: `Tirou 1x **${item.name}** na sorte semanal!`
            }
          ]
        })
      }
    }

    if (subcommand === 'mensal') {
      if (userData?.lastMonthlyRollAt && getMSFromNow(userData.lastMonthlyRollAt) < Duration.Month) {
        await interaction.editReply({
          content: `Você poderá fazer seu resgate mensal novamente <t:${~~((Date.now() + Duration.Month - getMSFromNow(userData.lastMonthlyRollAt)) / 1000)}:R>.`
        })
        return;
      }

      const item = getRandomItemByChance('monthly');

      await prisma.user.upsert({
        where: {
          id: interaction.user.id,
        },
        create: {
          id: interaction.user.id,
          inventoryItems: {
            create: {
              amount: 1,
              itemId: item.id,
            }
          },
          lastMonthlyRollAt: new Date(),
        },
        update: {
          inventoryItems: {
            create: {
              amount: 1,
              itemId: item.id,
            }
          },
          lastMonthlyRollAt: new Date(),
        }
      });

      await interaction.editReply({
        embeds: [
          {
            color: 0x00ff00,
            description: `Você ganhou 1x **${item.name}** na sua sorte mensal!`
          }
        ]
      })

      if (logsChannel?.isTextBased()) {
        await logsChannel.send({
          embeds: [
            {
              color: 0x00ffff,
              author: {
                name: interaction.user.username,
                icon_url: interaction.user.displayAvatarURL(),
              },
              description: `Tirou 1x **${item.name}** na sorte mensal!`
            }
          ]
        })
      }
    }
  }
}
