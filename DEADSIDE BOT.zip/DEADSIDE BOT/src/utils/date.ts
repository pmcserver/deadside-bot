export enum Duration {
  Second = 1000,
  Minute = Second * 60,
  Hour = Minute * 60,
  Day = Hour * 24,
  Week = Day * 7,
  Month = Day * 30
}

export function getMSFromNow(date: Date) {
  return Date.now() - date.getTime();
}
