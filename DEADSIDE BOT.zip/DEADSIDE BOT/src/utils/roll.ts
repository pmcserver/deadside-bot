import rollConfig from '@/config/roll.json' assert { type: "json" };
import { shuffleArray } from '.';

export function getItemByName(name: string) {
  return rollConfig.items.find(x => x.name === name);
}

export function getItemByItemId(id: number) {
  return rollConfig.items.find(x => x.id === id);
}

export function getRandomItemByChance(type: keyof typeof rollConfig['items'][number]['chance']) {
  const items = rollConfig.items.map(x => {
    return {
      id: x.id,
      name: x.name,
      chance: x.chance[type]
    }
  });

  shuffleArray(items);

  let item: typeof items[number] | null = null;

  while (!item) {
    item = items.find(x => {
      const rand = Math.random();
      return x.chance >= rand;
    }) ?? null;
  }

  return item;
}
