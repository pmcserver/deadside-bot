import 'dotenv/config';

import { Bot } from "./bot";

const bot = new Bot({
  intents: ['Guilds', 'GuildMembers'],
});

bot.start();

process.on('uncaughtException', console.error);
process.on('unhandledRejection', console.error);
