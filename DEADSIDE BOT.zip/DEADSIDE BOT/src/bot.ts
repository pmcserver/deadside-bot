import { Client } from "discord.js";
import readdir from "readdirp";
import { fileURLToPath, pathToFileURL } from "url";
import { env } from "./env";
import { Command } from "./structures/command";
import { Event } from "./structures/event";

export class Bot extends Client<true> {
  commands = new Map<string, Command>();

  get guild() {
    return this.guilds.resolve(env.DISCORD_GUILD_ID);
  }

  async start() {
    await this.loadEvents();

    await super.login(env.DISCORD_TOKEN);

    await this.loadCommands();
  }

  private async loadEvents() {
    const files = readdir(fileURLToPath(new URL('events', import.meta.url)));

    const loadedEvents = new Set<string>();

    for await (const file of files) {
      if (!/\.(js|ts)$/i.test(file.basename)) continue;

      const listener = await import(pathToFileURL(file.fullPath).href).then(res => new res.default(this));
      if (listener instanceof Event) {
        this.on(listener.eventName, listener.execute.bind(listener));
        loadedEvents.add(listener.eventName);
      }
    }

    console.log(`- The following events has been loaded: ${[...loadedEvents.keys()].join(', ')}`);
  }

  private async loadCommands() {
    const files = readdir(fileURLToPath(new URL('commands', import.meta.url)));

    for await (const file of files) {
      if (!/\.(js|ts)$/i.test(file.basename)) continue;

      const command = await import(pathToFileURL(file.fullPath).href).then(res => new res.default(this));
      if (command instanceof Command) {
        this.commands.set(command.name, command);
      }
    }

    console.log(`- ${this.commands.size} commands loaded successfully!`);

    if (process.argv.includes('--deploy-cmds')) {
      await this.registerCommands();
    }
  }

  public async registerCommands() {
    if (!this.guild) {
      console.log("The bot ins't the main guild and is unable to register the (/) slash commands.");
      return;
    }

    await this.guild.commands.set([...this.commands.values()].map(x => x.data));
    console.log('All (/) slash commands has been registered successfully!');
  }
}
