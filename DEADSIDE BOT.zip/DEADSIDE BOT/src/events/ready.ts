import { Bot } from "@/bot";
import { Event } from "@/structures/event";

export default class extends Event {
  constructor(client: Bot) {
    super(client, 'ready');
  }

  async execute() {
    console.log('-'.repeat(40));
    console.log(`Logged in as ${this.client.user.tag}`);
    console.log('-'.repeat(40));
  }
}
