import { Bot } from "@/bot";
import { Event } from "@/structures/event";
import { Interaction } from "discord.js";

export default class extends Event {
  constructor(client: Bot) {
    super(client, 'interactionCreate');
  }

  async execute(interaction: Interaction) {
    if (!interaction.isCommand() || !interaction.inCachedGuild())
      return;

    if (interaction.guildId !== this.client.guild?.id)
      return;

    const command = this.client.commands.get(interaction.commandName);
    if (command) {
      try {
        await command.run(interaction);
      } catch(err) {
        console.error(err);
      }
    }
  }
}
