import { Bot } from "@/bot";
import { env } from "@/env";
import { Event } from "@/structures/event";
import { Guild } from "discord.js";

export default class extends Event {
  constructor(client: Bot) {
    super(client, 'guildCreate');
  }

  async execute(guild: Guild) {
    if (guild.id === env.DISCORD_GUILD_ID) {
      await this.client.registerCommands();
    }
  }
}
